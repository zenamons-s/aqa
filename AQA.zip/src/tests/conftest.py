import os
import pathlib
import allure
import pytest
from dotenv import load_dotenv

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

load_dotenv()


def _env_bool(name: str, default: str = "true") -> bool:
    return os.getenv(name, default).strip().lower() in ("1", "true", "yes", "y")


@pytest.fixture(scope="session")
def base_url() -> str:
    return os.getenv("BASE_URL", "https://www.saucedemo.com").rstrip("/")


@pytest.fixture(scope="session", autouse=True)
def _allure_environment(base_url):
    results_dir = pathlib.Path("allure-results")
    results_dir.mkdir(exist_ok=True)
    props = [
        f"BASE_URL={base_url}",
        f"HEADLESS={os.getenv('HEADLESS', 'true')}",
        "IMPL=selenium",
    ]
    (results_dir / "environment.properties").write_text("\n".join(props), encoding="utf-8")


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    # даёт доступ к item.rep_call.failed внутри fixture driver
    outcome = yield
    rep = outcome.get_result()
    setattr(item, "rep_" + rep.when, rep)


@pytest.fixture
def driver(request):
    headless = _env_bool("HEADLESS", "true")

    chromium_bin = os.getenv("CHROME_BIN", "/usr/bin/chromium")
    chromedriver_bin = os.getenv("CHROMEDRIVER_BIN", "/usr/bin/chromedriver")

    options = Options()

    # ВАЖНО: бинарь
    options.binary_location = chromium_bin

    # must-have для WSL/Docker/CI (иначе Chrome часто "exited")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--disable-software-rasterizer")
    options.add_argument("--remote-debugging-port=9222")
    options.add_argument("--window-size=1280,720")

    # ВАЖНО: отдельный профиль (часто лечит падение snap chromium)
    options.add_argument("--user-data-dir=/tmp/chrome-user-data")
    options.add_argument("--data-path=/tmp/chrome-data")
    options.add_argument("--disk-cache-dir=/tmp/chrome-cache")

    # Иногда помогает в средах без нормального dbus/портала
    options.add_argument("--no-first-run")
    options.add_argument("--no-default-browser-check")

    if headless:
        options.add_argument("--headless=new")

    # Лог chromedriver (если снова упадёт — откроешь chromedriver.log и сразу видно почему)
    service = Service(executable_path=chromedriver_bin, log_output="chromedriver.log")

    drv = webdriver.Chrome(service=service, options=options)
    drv.implicitly_wait(0)  # используем explicit waits

    try:
        yield drv
    finally:
        failed = getattr(request.node, "rep_call", None) and request.node.rep_call.failed
        if failed:
            try:
                allure.attach(drv.current_url, name="page_url", attachment_type=allure.attachment_type.TEXT)
            except Exception:
                pass
            try:
                allure.attach(drv.get_screenshot_as_png(), name="screenshot", attachment_type=allure.attachment_type.PNG)
            except Exception:
                pass
            try:
                allure.attach(drv.page_source, name="page_html", attachment_type=allure.attachment_type.HTML)
            except Exception:
                pass

        try:
            drv.quit()
        except Exception:
            pass

    drv.quit()
